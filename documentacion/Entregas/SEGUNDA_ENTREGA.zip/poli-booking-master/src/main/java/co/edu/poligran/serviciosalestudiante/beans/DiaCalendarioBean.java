package co.edu.poligran.serviciosalestudiante.beans;

import java.util.Date;

public class DiaCalendarioBean {
    private Date dia;

    public Date getDia() {
        return dia;
    }

    public void setDia(Date dia) {
        this.dia = dia;
    }
}
