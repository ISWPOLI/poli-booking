package co.edu.poligran.serviciosalestudiante;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiciosAlEstudianteApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServiciosAlEstudianteApplication.class, args);
	}
}
