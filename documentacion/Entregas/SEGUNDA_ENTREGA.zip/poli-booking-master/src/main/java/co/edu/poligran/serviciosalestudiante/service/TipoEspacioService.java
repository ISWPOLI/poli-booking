package co.edu.poligran.serviciosalestudiante.service;

import co.edu.poligran.serviciosalestudiante.service.dto.TipoEspacioDTO;

public interface TipoEspacioService {
    TipoEspacioDTO buscarTipoEspacioPorNombre(String tipoEspacio);
}
