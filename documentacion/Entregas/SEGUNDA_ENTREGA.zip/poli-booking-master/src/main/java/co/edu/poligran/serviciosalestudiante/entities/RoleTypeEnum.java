package co.edu.poligran.serviciosalestudiante.entities;

public enum RoleTypeEnum {
	ADMIN, FACULTY_OR_STAFF, STUDENT;
}
