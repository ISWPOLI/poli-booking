# poli-booking
Repositorio para proyecto de Ingeniería del Software II en Politécnico Grancolombiano.

Poli Booking es una aplicacin web que permite reservar algunos de los servicios al estudiante en el Politécnico Grancolombiano como por ejemplo:
* Salas de biblioteca
* Gimansio
* Canchas de deportes

Para los detalles técnicos por favor revisa la wiki del proyecto:
https://github.com/ISWPOLI/poli-booking/wiki
