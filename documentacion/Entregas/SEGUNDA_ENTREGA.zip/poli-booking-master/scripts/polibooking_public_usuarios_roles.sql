INSERT INTO public.usuarios_roles (user_id, user_role_id) VALUES (316, 1);
INSERT INTO public.usuarios_roles (user_id, user_role_id) VALUES (317, 3);