INSERT INTO public.roles (id, type) VALUES (1, 'ADMIN');
INSERT INTO public.roles (id, type) VALUES (2, 'FACULTY_OR_STAFF');
INSERT INTO public.roles (id, type) VALUES (3, 'STUDENT');