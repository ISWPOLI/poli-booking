INSERT INTO public.tipo_espacio (id, nombre) VALUES (4, 'CUBICULO_ESTUDIO');
INSERT INTO public.tipo_espacio (id, nombre) VALUES (5, 'CUBICULO_VIDEO');
INSERT INTO public.tipo_espacio (id, nombre) VALUES (6, 'GIMNASIO');
INSERT INTO public.tipo_espacio (id, nombre) VALUES (7, 'CANCHA_TENIS');
INSERT INTO public.tipo_espacio (id, nombre) VALUES (8, 'CANCHA_MULTIPLE');
INSERT INTO public.tipo_espacio (id, nombre) VALUES (9, 'CANCHA_FUTBOL');